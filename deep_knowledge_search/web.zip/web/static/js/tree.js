let ws;
const statusEl = document.getElementById('status');
const logsEl = document.getElementById('logs');
const treeContainer = document.getElementById('treeContainer');
const mainContent = document.getElementById('mainContent');
const detailPanel = document.getElementById('detailPanel');
const panelContent = document.getElementById('panelContent');
const panelTitle = document.getElementById('panelTitle');

let logCount = 0;
let taskData = null;
let selectedNodeId = null;
let collapsedNodes = new Set();

function connect() {
    ws = new WebSocket('ws://' + location.host + '/ws');
    ws.onopen = () => {
        statusEl.textContent = '已连接';
        statusEl.classList.remove('disconnected');
    };
    ws.onclose = () => {
        statusEl.textContent = '已断开';
        statusEl.classList.add('disconnected');
        setTimeout(connect, 2000);
    };
    ws.onmessage = (e) => {
        const msg = JSON.parse(e.data);
        handleMessage(msg);
    };
}

function handleMessage(msg) {
    switch (msg.type) {
        case 'task_start':
            taskData = { title: msg.data.title, status: 'running', children: [] };
            clearLogs();
            addLog('info', '任务开始: ' + msg.data.title, msg.time);
            renderTree();
            break;
        case 'task_complete':
            if (taskData) taskData.status = 'done';
            addLog('info', '✅ 任务完成', msg.time);
            renderTree();
            break;
        case 'task_failed':
            if (taskData) taskData.status = 'failed';
            addLog('error', '❌ 任务失败: ' + msg.data.error, msg.time);
            renderTree();
            break;
        case 'node_start':
        case 'node_complete':
        case 'node_failed':
            updateTaskData(msg.data);
            addLog(msg.type === 'node_failed' ? 'error' : 'info',
                (msg.type === 'node_start' ? '▶ ' : msg.type === 'node_complete' ? '✓ ' : '✗ ') + msg.data.title,
                msg.time);
            renderTree();
            break;
        case 'tree_update':
        case 'node_data':
            if (msg.type === 'tree_update') {
                taskData = msg.data;
            } else {
                updateTaskData(msg.data);
            }
            renderTree();
            break;
        case 'log':
            addLog(msg.data.level, msg.data.message, msg.time);
            break;
    }
}

function updateTaskData(nodeData) {
    if (!taskData) {
        taskData = nodeData;
    } else if (!taskData.id && nodeData.depth === 0) {
        taskData = nodeData;
    } else {
        mergeNodeData(taskData, nodeData);
    }
}

function mergeNodeData(target, source) {
    if (target.id === source.id) {
        const existingChildren = target.children || [];
        Object.assign(target, source);
        if (!source.children && existingChildren.length > 0) {
            target.children = existingChildren;
        }
        return true;
    }
    if (source.parent_id === target.id) {
        if (!target.children) target.children = [];
        const existing = target.children.find(c => c.id === source.id);
        if (existing) {
            const existingChildren = existing.children || [];
            Object.assign(existing, source);
            if (!source.children && existingChildren.length > 0) {
                existing.children = existingChildren;
            }
        } else {
            target.children.push(source);
        }
        return true;
    }
    if (target.children) {
        for (let child of target.children) {
            if (mergeNodeData(child, source)) return true;
        }
    }
    return false;
}

function renderTree() {
    if (!taskData) {
        treeContainer.innerHTML = '<div class="empty-state">等待任务开始...</div>';
        return;
    }
    treeContainer.innerHTML = renderNode(taskData, true);
    updateStats();
}

function renderNode(node, isRoot) {
    const hasChildren = node.children && node.children.length > 0;
    const isCollapsed = collapsedNodes.has(node.id);
    const isSelected = selectedNodeId === node.id;
    const status = node.status || 'pending';

    let html = '<div class="tree-node' + (isRoot ? ' root' : '') + '">';
    html += '<div class="node-header' + (isSelected ? ' selected' : '') + '" onclick="selectNode(\'' + node.id + '\')">';

    if (hasChildren) {
        html += '<span class="toggle-btn has-children" onclick="event.stopPropagation();toggleNode(\'' + node.id + '\')">' + (isCollapsed ? '▶' : '▼') + '</span>';
    } else {
        html += '<span class="toggle-btn">•</span>';
    }

    html += '<span class="status-icon status-' + status + '"></span>';
    html += '<span class="node-title">' + escapeHtml(node.title || 'Task') + '</span>';

    // 显示耗时
    if (node.started_at) {
        const start = new Date(node.started_at);
        const end = node.finished_at ? new Date(node.finished_at) : new Date();
        // 如果任务未完成且未运行（如暂停或失败），使用最后更新时间或保持当前时间
        // 这里简化处理：如果是 running，计算动态耗时；如果是 done/failed，计算固定耗时

        let duration = 0;
        if (node.finished_at) {
            duration = new Date(node.finished_at) - start;
        } else if (node.status === 'running') {
            duration = new Date() - start;
        }

        if (duration > 0) {
            let durationStr = '';
            if (duration < 1000) durationStr = duration + 'ms';
            else if (duration < 60000) durationStr = (duration / 1000).toFixed(1) + 's';
            else durationStr = (duration / 60000).toFixed(1) + 'm';

            if (!node.finished_at && node.status === 'running') {
                durationStr += '...';
            }

            // 只有当耗时有意义时才显示
            html += '<span class="node-badge" style="background:rgba(107,114,128,0.1);color:#6b7280" title="开始: ' + new Date(node.started_at).toLocaleTimeString() + '">⏱️ ' + durationStr + '</span>';
        }
    }

    if (node.llm_calls && node.llm_calls.length > 0) {
        html += '<span class="node-badge">LLM: ' + node.llm_calls.length + '</span>';
    }

    // 显示执行模式徽章（仅对有子节点的节点显示）
    if (hasChildren && node.execution_mode) {
        if (node.execution_mode === 'parallel') {
            html += '<span class="node-badge" style="background:rgba(59,130,246,0.2);color:#3b82f6">🔀 并行</span>';
        } else {
            html += '<span class="node-badge" style="background:rgba(156,163,175,0.2);color:#9ca3af">➡️ 串行</span>';
        }
    }

    // 显示验证徽章
    if (node.verification) {
        if (node.verification.passed) {
            html += '<span class="node-badge" style="background:rgba(34,197,94,0.2);color:#22c55e">✓ 验证通过</span>';
        } else if (node.verification.iterations > 0) {
            html += '<span class="node-badge" style="background:rgba(251,191,36,0.2);color:#fbbf24">验证中(' + node.verification.iterations + ')</span>';
        }
    }

    html += '</div>';

    if (hasChildren) {
        html += '<div class="children-container' + (isCollapsed ? ' collapsed' : '') + '">';
        for (const child of node.children) {
            html += renderNode(child, false);
        }
        html += '</div>';
    }

    html += '</div>';
    return html;
}

function toggleNode(nodeId) {
    if (collapsedNodes.has(nodeId)) {
        collapsedNodes.delete(nodeId);
    } else {
        collapsedNodes.add(nodeId);
    }
    renderTree();
}

// 收集所有节点ID
function collectAllNodeIds(node, ids) {
    if (!node) return;
    if (node.id) ids.push(node.id);
    if (node.children) {
        for (const child of node.children) {
            collectAllNodeIds(child, ids);
        }
    }
}

// 展开全部
function expandAll() {
    collapsedNodes.clear();
    renderTree();
}

// 折叠全部
function collapseAll() {
    if (!taskData) return;
    const allIds = [];
    collectAllNodeIds(taskData, allIds);
    collapsedNodes = new Set(allIds);
    renderTree();
}

// 统计节点数量
function countNodes(node) {
    const stats = { done: 0, running: 0, pending: 0, failed: 0, canceled: 0, total: 0 };
    if (!node) return stats;

    function count(n) {
        if (!n) return;
        stats.total++;
        const status = n.status || 'pending';
        if (status === 'done') stats.done++;
        else if (status === 'running') stats.running++;
        else if (status === 'failed') stats.failed++;
        else if (status === 'canceled') stats.canceled++;
        else stats.pending++;

        if (n.children) {
            for (const child of n.children) {
                count(child);
            }
        }
    }
    count(node);
    return stats;
}

// 更新统计显示
function updateStats() {
    const stats = countNodes(taskData);
    document.getElementById('statDone').textContent = stats.done;
    document.getElementById('statRunning').textContent = stats.running;
    document.getElementById('statPending').textContent = stats.pending;
    document.getElementById('statFailed').textContent = stats.failed + stats.canceled;
}

function findNode(node, id) {
    if (node.id === id) return node;
    if (node.children) {
        for (const child of node.children) {
            const found = findNode(child, id);
            if (found) return found;
        }
    }
    return null;
}

function selectNode(nodeId) {
    selectedNodeId = nodeId;
    renderTree();
    const node = findNode(taskData, nodeId);
    if (node) showNodeDetail(node);
}

function showNodeDetail(node) {
    panelTitle.textContent = node.title || 'Task Node';

    let html = '';
    html += '<div class="panel-section">';
    html += '<div class="section-title">📋 基本信息</div>';
    html += '<div class="node-info">';
    html += '<div class="info-row"><span class="info-label">ID:</span><span class="info-value">' + node.id + '</span></div>';
    html += '<div class="info-row"><span class="info-label">状态:</span><span class="info-value"><span class="status-icon status-' + (node.status || 'pending') + '" style="display:inline-block;vertical-align:middle"></span> ' + (node.status || 'pending') + '</span></div>';

    // 时间信息
    if (node.created_at) {
        html += '<div class="info-row"><span class="info-label">创建时间:</span><span class="info-value">' + new Date(node.created_at).toLocaleString() + '</span></div>';
    }
    if (node.started_at) {
        html += '<div class="info-row"><span class="info-label">开始时间:</span><span class="info-value">' + new Date(node.started_at).toLocaleString() + '</span></div>';
    }
    if (node.finished_at) {
        html += '<div class="info-row"><span class="info-label">结束时间:</span><span class="info-value">' + new Date(node.finished_at).toLocaleString() + '</span></div>';

        // 计算总耗时
        if (node.started_at) {
            const duration = new Date(node.finished_at) - new Date(node.started_at);
            let durationStr = '';
            if (duration < 1000) durationStr = duration + 'ms';
            else if (duration < 60000) durationStr = (duration / 1000).toFixed(2) + 's';
            else durationStr = (duration / 60000).toFixed(2) + 'm';
            html += '<div class="info-row"><span class="info-label">总耗时:</span><span class="info-value">' + durationStr + '</span></div>';
        }
    }
    if (node.description) {
        html += '<div class="info-row"><span class="info-label">描述:</span><span class="info-value">' + escapeHtml(node.description) + '</span></div>';
    }
    if (node.goal) {
        html += '<div class="info-row"><span class="info-label">目标:</span><span class="info-value">' + escapeHtml(node.goal) + '</span></div>';
    }
    html += '</div></div>';

    if (node.llm_calls && node.llm_calls.length > 0) {
        html += '<div class="panel-section">';
        html += '<div class="section-title">🤖 LLM 调用记录 (' + node.llm_calls.length + ')</div>';

        const typeLabels = { plan: '规划', execute: '执行', synthesize: '整合', verify: '验证' };
        node.llm_calls.forEach((call, idx) => {
            html += '<div class="llm-call">';
            html += '<div class="llm-call-header" onclick="toggleLLMCall(' + idx + ')">';
            html += '<span class="llm-type">' + (typeLabels[call.type] || call.type) + '</span>';
            html += '<span class="llm-duration">' + call.duration_ms + 'ms</span>';
            html += '</div>';
            html += '<div class="llm-call-body" id="llm-call-' + idx + '">';
            html += '<div class="sub-label">请求:</div>';
            html += '<div class="code-block request">' + escapeHtml(JSON.stringify(call.messages, null, 2)) + '</div>';
            html += '<div class="sub-label">响应:</div>';
            html += '<div class="code-block response">' + escapeHtml(call.response) + '</div>';
            html += '</div></div>';
        });
        html += '</div>';
    }

    // 验证信息
    if (node.verification) {
        html += '<div class="panel-section">';
        html += '<div class="section-title">🔍 验证结果</div>';
        html += '<div class="node-info">';
        html += '<div class="info-row"><span class="info-label">状态:</span><span class="info-value">' + (node.verification.passed ? '<span style="color:#22c55e">✓ 通过</span>' : '<span style="color:#fbbf24">未通过</span>') + '</span></div>';
        html += '<div class="info-row"><span class="info-label">次数:</span><span class="info-value">' + node.verification.iterations + ' 次</span></div>';
        html += '</div>';

        if (node.verification.attempts && node.verification.attempts.length > 0) {
            html += '<div style="margin-top:10px">';
            node.verification.attempts.forEach((attempt, idx) => {
                const bgColor = attempt.passed ? 'rgba(34,197,94,0.1)' : 'rgba(251,191,36,0.1)';
                const borderColor = attempt.passed ? '#22c55e' : '#fbbf24';
                html += '<div style="background:' + bgColor + ';border-left:2px solid ' + borderColor + ';padding:8px;margin-bottom:6px;border-radius:0 4px 4px 0">';
                html += '<div style="font-size:0.8em;color:#888;margin-bottom:4px">第 ' + attempt.iteration + ' 次验证 (' + attempt.timestamp + ')</div>';
                html += '<div style="font-size:0.85em">' + escapeHtml(attempt.feedback) + '</div>';
                html += '</div>';
            });
            html += '</div>';
        }
        html += '</div>';
    }

    if (node.result) {
        html += '<div class="panel-section">';
        html += '<div class="section-title">📝 执行结果</div>';
        html += '<div class="code-block">' + escapeHtml(node.result.summary || node.result.output || JSON.stringify(node.result)) + '</div>';
        html += '</div>';
    }

    panelContent.innerHTML = html;
    detailPanel.classList.add('open');
    mainContent.classList.add('panel-open');
}

function toggleLLMCall(idx) {
    const body = document.getElementById('llm-call-' + idx);
    body.classList.toggle('open');
}

function closePanel() {
    detailPanel.classList.remove('open');
    mainContent.classList.remove('panel-open');
    selectedNodeId = null;
    renderTree();
}

function escapeHtml(text) {
    if (!text) return '';
    return text.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function addLog(level, message, time) {
    if (logCount === 0) logsEl.innerHTML = '';
    const entry = document.createElement('div');
    entry.className = 'log-entry ' + level;
    entry.innerHTML = '<span class="log-time">' + time + '</span>' + escapeHtml(message);
    logsEl.insertBefore(entry, logsEl.firstChild);
    logCount++;
    if (logCount > 30) logsEl.removeChild(logsEl.lastChild);
}

function clearLogs() {
    logsEl.innerHTML = '';
    logCount = 0;
}

// =========================================
// 标签页切换
// =========================================
function switchTab(tabName) {
    // 更新标签样式
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');

    // 切换内容
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById('tab-' + tabName).classList.add('active');

    // 加载数据
    if (tabName === 'history') loadHistory();
    if (tabName === 'docs') loadDocs();
}

// =========================================
// 历史记录
// =========================================
let historyData = [];
let selectedHistoryId = null;

async function loadHistory() {
    try {
        const response = await fetch('/api/history');
        const data = await response.json();
        historyData = data.history || [];
        renderHistoryList();
    } catch (e) {
        document.getElementById('historyList').innerHTML = '<div class="empty-state">加载失败</div>';
    }
}

function renderHistoryList() {
    const container = document.getElementById('historyList');
    if (!historyData || historyData.length === 0) {
        container.innerHTML = '<div class="empty-state">暂无历史记录</div>';
        return;
    }

    let html = '';
    historyData.forEach(item => {
        const isSelected = selectedHistoryId === item.id;
        const statusClass = item.success ? 'success' : 'failed';
        const startTime = item.start_time ? new Date(item.start_time).toLocaleString('zh-CN') : '';

        html += '<div class="history-item' + (isSelected ? ' selected' : '') + '" onclick="selectHistory(\'' + item.id + '\')">';
        html += '<div class="history-title"><span class="history-status ' + statusClass + '"></span>' + escapeHtml(item.title || '未命名任务') + '</div>';
        html += '<div class="history-meta">';
        html += '<span>⏱️ ' + startTime + '</span>';
        html += '<span>' + (item.success ? '✅ 成功' : '❌ 失败') + '</span>';
        html += '</div></div>';
    });
    container.innerHTML = html;
}

async function selectHistory(id) {
    selectedHistoryId = id;
    renderHistoryList();

    try {
        const response = await fetch('/api/history/' + encodeURIComponent(id));
        const data = await response.json();

        // 使用历史数据渲染树
        if (data && !data.error) {
            // 转换为树结构
            const treeData = convertHistoryToTree(data);
            taskData = treeData;
            renderTree();
            switchTab('current');
            document.querySelectorAll('.nav-tab')[0].classList.add('active');
        }
    } catch (e) {
        console.error('加载历史详情失败', e);
    }
}

function convertHistoryToTree(data) {
    const node = {
        id: data.task_id,
        title: data.title,
        description: data.description,
        status: data.success ? 'done' : 'failed',
        result: data.result,
        children: []
    };

    if (data.children) {
        node.children = data.children.map(child => convertHistoryToTree(child));
    }

    return node;
}

// =========================================
// 文档浏览
// =========================================
let docsData = [];
let selectedDocPath = null;

async function loadDocs() {
    try {
        const response = await fetch('/api/docs');
        const data = await response.json();
        docsData = data.docs || [];
        renderDocTree();
    } catch (e) {
        document.getElementById('docTree').innerHTML = '<div class="empty-state">加载失败</div>';
    }
}

function renderDocTree() {
    const container = document.getElementById('docTree');
    if (!docsData || docsData.length === 0) {
        container.innerHTML = '<div class="empty-state">暂无文档</div>';
        return;
    }

    // 构建树结构（同时支持正斜杠和反斜杠作为分隔符）
    const tree = {};
    docsData.forEach(doc => {
        const parts = doc.path.split(/[\/\\]/);
        let current = tree;
        parts.forEach((part, idx) => {
            if (!part) return; // 跳过空字符串
            if (!current[part]) {
                current[part] = { _info: idx === parts.length - 1 ? doc : { is_dir: true }, _children: {} };
            }
            current = current[part]._children;
        });
    });

    container.innerHTML = renderDocFolder(tree, '');
}

function renderDocFolder(folder, prefix) {
    let html = '';
    const entries = Object.entries(folder).sort((a, b) => {
        const aIsDir = Object.keys(a[1]._children).length > 0;
        const bIsDir = Object.keys(b[1]._children).length > 0;
        if (aIsDir !== bIsDir) return bIsDir - aIsDir;
        return a[0].localeCompare(b[0]);
    });

    entries.forEach(([name, data]) => {
        const path = prefix ? prefix + '/' + name : name;
        const hasChildren = Object.keys(data._children).length > 0;
        const isDir = data._info && data._info.is_dir;

        if (isDir || hasChildren) {
            html += '<div class="doc-item folder" onclick="toggleDocFolder(this)">📁 ' + escapeHtml(name) + '</div>';
            html += '<div class="doc-folder-items">';
            html += renderDocFolder(data._children, path);
            html += '</div>';
        } else {
            const isSelected = selectedDocPath === path;
            html += '<div class="doc-item file' + (isSelected ? ' selected' : '') + '" onclick="viewDoc(\'' + path.replace(/'/g, "\\'") + '\')">📄 ' + escapeHtml(name) + '</div>';
        }
    });
    return html;
}

function toggleDocFolder(el) {
    const folder = el.nextElementSibling;
    folder.classList.toggle('open');
    el.textContent = (folder.classList.contains('open') ? '📂 ' : '📁 ') + el.textContent.slice(3);
}

async function viewDoc(path) {
    // 更新选中状态（不重新渲染整个树）
    document.querySelectorAll('.doc-item.file').forEach(el => {
        el.classList.remove('selected');
    });
    // 找到对应的文件元素并添加选中状态
    document.querySelectorAll('.doc-item.file').forEach(el => {
        const elPath = el.getAttribute('onclick').match(/viewDoc\('(.+?)'\)/);
        if (elPath && elPath[1].replace(/\\'/g, "'") === path) {
            el.classList.add('selected');
        }
    });
    selectedDocPath = path;

    const viewer = document.getElementById('docViewer');
    viewer.innerHTML = '<div class="empty-state">加载中...</div>';

    try {
        const response = await fetch('/api/docs/' + encodeURIComponent(path));
        const content = await response.text();

        if (response.ok) {
            viewer.innerHTML = '<div class="markdown-content">' + renderMarkdown(content) + '</div>';
        } else {
            viewer.innerHTML = '<div class="empty-state">加载失败</div>';
        }
    } catch (e) {
        viewer.innerHTML = '<div class="empty-state">加载失败</div>';
    }
}

// 简单的 Markdown 渲染
function renderMarkdown(text) {
    let html = escapeHtml(text);
    const bt = String.fromCharCode(96); // backtick character

    // 代码块
    const codeBlockRe = new RegExp(bt + bt + bt + '(\\w*)\\n([\\s\\S]*?)' + bt + bt + bt, 'g');
    html = html.replace(codeBlockRe, '<pre><code>$2</code></pre>');

    // 行内代码
    const inlineCodeRe = new RegExp(bt + '([^' + bt + ']+)' + bt, 'g');
    html = html.replace(inlineCodeRe, '<code>$1</code>');

    // 标题
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

    // 粗体和斜体
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');

    // 表格处理
    html = renderMarkdownTables(html);

    // 列表
    html = html.replace(/^- (.+)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

    // 引用
    html = html.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>');

    // 段落
    html = html.replace(/\n\n/g, '</p><p>');
    html = '<p>' + html + '</p>';

    // 清理
    html = html.replace(/<p><\/p>/g, '');
    html = html.replace(/<p>(<h[123]>)/g, '$1');
    html = html.replace(/(<\/h[123]>)<\/p>/g, '$1');
    html = html.replace(/<p>(<ul>)/g, '$1');
    html = html.replace(/(<\/ul>)<\/p>/g, '$1');
    html = html.replace(/<p>(<pre>)/g, '$1');
    html = html.replace(/(<\/pre>)<\/p>/g, '$1');
    html = html.replace(/<p>(<blockquote>)/g, '$1');
    html = html.replace(/(<\/blockquote>)<\/p>/g, '$1');
    html = html.replace(/<p>(<table)/g, '$1');
    html = html.replace(/(<\/table>)<\/p>/g, '$1');

    return html;
}

// 渲染 Markdown 表格
function renderMarkdownTables(html) {
    const lines = html.split('\n');
    const result = [];
    let i = 0;

    while (i < lines.length) {
        const line = lines[i];

        // 检查是否是表格行（以 | 开头或包含 |）
        if (line.trim().startsWith('|') || (line.includes('|') && i + 1 < lines.length && lines[i + 1].match(/^\|?[\s\-:|]+\|/))) {
            // 尝试解析表格
            const tableLines = [];
            let j = i;

            // 收集所有表格行
            while (j < lines.length && (lines[j].includes('|') || lines[j].trim() === '')) {
                if (lines[j].trim() === '') {
                    // 空行可能结束表格
                    if (tableLines.length > 0) break;
                } else {
                    tableLines.push(lines[j]);
                }
                j++;
            }

            // 至少需要2行（表头+分隔符）才能构成表格
            if (tableLines.length >= 2 && tableLines[1].match(/^\|?[\s\-:|]+\|/)) {
                const tableHtml = parseMarkdownTable(tableLines);
                if (tableHtml) {
                    result.push(tableHtml);
                    i = j;
                    continue;
                }
            }
        }

        result.push(line);
        i++;
    }

    return result.join('\n');
}

// 解析单个 Markdown 表格
function parseMarkdownTable(lines) {
    if (lines.length < 2) return null;

    // 解析表头
    const headerCells = parseTableRow(lines[0]);
    if (headerCells.length === 0) return null;

    // 解析对齐方式
    const alignments = parseTableAlignments(lines[1], headerCells.length);
    if (!alignments) return null;

    // 构建表格 HTML
    let tableHtml = '<table class="md-table">\n<thead>\n<tr>';
    headerCells.forEach((cell, idx) => {
        const align = alignments[idx] ? ' style="text-align:' + alignments[idx] + '"' : '';
        tableHtml += '<th' + align + '>' + cell.trim() + '</th>';
    });
    tableHtml += '</tr>\n</thead>\n<tbody>';

    // 解析数据行
    for (let i = 2; i < lines.length; i++) {
        const cells = parseTableRow(lines[i]);
        if (cells.length === 0) continue;

        tableHtml += '\n<tr>';
        for (let j = 0; j < headerCells.length; j++) {
            const align = alignments[j] ? ' style="text-align:' + alignments[j] + '"' : '';
            const cellContent = j < cells.length ? cells[j].trim() : '';
            tableHtml += '<td' + align + '>' + cellContent + '</td>';
        }
        tableHtml += '</tr>';
    }

    tableHtml += '\n</tbody>\n</table>';
    return tableHtml;
}

// 解析表格行
function parseTableRow(line) {
    // 移除首尾的 |
    let trimmed = line.trim();
    if (trimmed.startsWith('|')) trimmed = trimmed.slice(1);
    if (trimmed.endsWith('|')) trimmed = trimmed.slice(0, -1);

    // 按 | 分割
    return trimmed.split('|');
}

// 解析表格对齐方式
function parseTableAlignments(line, expectedColumns) {
    const cells = parseTableRow(line);
    if (cells.length === 0) return null;

    const alignments = [];
    for (const cell of cells) {
        const trimmed = cell.trim();
        // 检查是否是分隔符行
        if (!trimmed.match(/^:?-+:?$/)) {
            return null; // 不是有效的分隔符
        }

        if (trimmed.startsWith(':') && trimmed.endsWith(':')) {
            alignments.push('center');
        } else if (trimmed.endsWith(':')) {
            alignments.push('right');
        } else if (trimmed.startsWith(':')) {
            alignments.push('left');
        } else {
            alignments.push('');
        }
    }

    // 补齐对齐方式
    while (alignments.length < expectedColumns) {
        alignments.push('');
    }

    return alignments;
}

// =========================================
// 可恢复任务
// =========================================
let recoverableData = [];

async function loadRecoverableTasks() {
    try {
        const response = await fetch('/api/task/recoverable');
        const data = await response.json();
        if (data.success && data.tasks && data.tasks.length > 0) {
            recoverableData = data.tasks;
            renderRecoverableTasks();
            document.getElementById('recoverableTasks').style.display = 'block';
        } else {
            document.getElementById('recoverableTasks').style.display = 'none';
        }
    } catch (e) {
        console.error('加载可恢复任务失败', e);
        document.getElementById('recoverableTasks').style.display = 'none';
    }
}

function renderRecoverableTasks() {
    const container = document.getElementById('recoverableList');
    if (!recoverableData || recoverableData.length === 0) {
        container.innerHTML = '<div class="empty-state">暂无可恢复的任务</div>';
        return;
    }

    let html = '';
    recoverableData.forEach(task => {
        const statusClass = task.status === 'running' ? 'running' : 'paused';
        html += '<div class="recoverable-item">';
        html += '<div class="recoverable-info">';
        html += '<span class="recoverable-status ' + statusClass + '"></span>';
        html += '<span class="recoverable-title">' + escapeHtml(task.title) + '</span>';
        html += '<span class="recoverable-folder">' + escapeHtml(task.task_folder) + '</span>';
        html += '</div>';
        html += '<button class="btn btn-primary" onclick="recoverTask(\'' + escapeHtml(task.task_folder).replace(/'/g, "\\'") + '\')">恢复</button>';
        html += '</div>';
    });
    container.innerHTML = html;
}

async function recoverTask(taskFolder) {
    try {
        const response = await fetch('/api/task/recover/' + encodeURIComponent(taskFolder), {
            method: 'POST'
        });
        const data = await response.json();
        if (data.success) {
            alert('任务恢复已启动！');
            // 隐藏可恢复任务列表
            document.getElementById('recoverableTasks').style.display = 'none';
        } else {
            alert('恢复失败: ' + (data.error || data.message));
        }
    } catch (e) {
        alert('恢复失败: ' + e.message);
    }
}

// 页面加载时尝试加载可恢复任务
setTimeout(loadRecoverableTasks, 1000);

connect();
